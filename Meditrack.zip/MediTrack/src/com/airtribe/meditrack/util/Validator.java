package com.airtribe.meditrack.util;

public class Validator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
