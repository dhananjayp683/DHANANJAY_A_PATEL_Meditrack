package com.airtribe.meditrack.util;

public class IdGenerator {
    private static int counter;

    static {
        counter = 1000;
    }

    private IdGenerator() {}

    public static synchronized int generate() {
        return counter++;
    }
}
