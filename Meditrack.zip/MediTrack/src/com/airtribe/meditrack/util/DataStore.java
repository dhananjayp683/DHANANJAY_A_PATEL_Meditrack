package com.airtribe.meditrack.util;

import java.util.*;

public class DataStore<T> {
    private Map<Integer, T> store = new HashMap<>();

    public void add(int id, T item) {
        store.put(id, item);
    }

    public T get(int id) {
        return store.get(id);
    }

    public void remove(int id) {
        store.remove(id);
    }

    public Collection<T> getAll() {
        return store.values();
    }

    public boolean exists(int id) {
        return store.containsKey(id);
    }
}
