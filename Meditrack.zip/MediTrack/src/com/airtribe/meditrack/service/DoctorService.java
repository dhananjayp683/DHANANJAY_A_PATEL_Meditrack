package com.airtribe.meditrack.service;

import com.airtribe.meditrack.entity.Doctor;
import com.airtribe.meditrack.enums.Specialization;
import com.airtribe.meditrack.util.DataStore;

import java.util.List;
import java.util.stream.Collectors;

public class DoctorService {

    private DataStore<Doctor> doctorStore = new DataStore<>();

    public void addDoctor(int id, Doctor doctor) {
        doctorStore.add(id, doctor);
    }

    public Doctor getDoctor(int id) {
        return doctorStore.get(id);
    }

    public void deleteDoctor(int id) {
        doctorStore.remove(id);
    }

    public List<Doctor> searchBySpecialization(Specialization specialization) {
        return doctorStore.getAll()
                .stream()
                .filter(d -> d.getSpecialization() == specialization)
                .collect(Collectors.toList());
    }

    public void listDoctors() {
        doctorStore.getAll().forEach(Doctor::display);
    }
}
