package com.airtribe.meditrack.service;

import com.airtribe.meditrack.entity.Patient;
import com.airtribe.meditrack.util.DataStore;

public class PatientService {

    private DataStore<Patient> patientStore = new DataStore<>();

    public void addPatient(int id, Patient patient) {
        patientStore.add(id, patient);
    }

    public Patient getPatient(int id) {
        return patientStore.get(id);
    }

    public void deletePatient(int id) {
        patientStore.remove(id);
    }

    public void listPatients() {
        patientStore.getAll().forEach(Patient::display);
    }
}
