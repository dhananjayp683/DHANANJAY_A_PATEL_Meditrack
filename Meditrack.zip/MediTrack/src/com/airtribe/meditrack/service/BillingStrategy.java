package com.airtribe.meditrack.service;

public abstract class BillingStrategy {
    public abstract double calculate(double baseAmount);
}
