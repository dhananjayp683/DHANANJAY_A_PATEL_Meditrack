package com.airtribe.meditrack.service;

import com.airtribe.meditrack.entity.Appointment;
import com.airtribe.meditrack.enums.AppointmentStatus;
import com.airtribe.meditrack.util.DataStore;

public class AppointmentService {

    private DataStore<Appointment> appointmentStore = new DataStore<>();

    public void createAppointment(int id, Appointment appointment) {
        appointmentStore.add(id, appointment);
    }

    public void cancelAppointment(int id) {
        Appointment appt = appointmentStore.get(id);
        if (appt != null) {
            appt.cancel();
        }
    }

    public void viewAppointments() {
        appointmentStore.getAll()
                .forEach(a -> System.out.println(a));
    }
}
