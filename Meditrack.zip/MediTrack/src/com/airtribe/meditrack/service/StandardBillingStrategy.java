package com.airtribe.meditrack.service;

//import com.airtribe.meditrack.interfaces.BillingStrategy;

public class StandardBillingStrategy extends BillingStrategy {
    @Override
    public double calculate(double baseAmount) {
        return baseAmount + baseAmount * 0.18;
    }
}
