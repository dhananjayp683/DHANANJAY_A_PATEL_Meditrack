package com.airtribe.meditrack.service;

//import com.airtribe.meditrack.interfaces.BillingStrategy;

public class InsuranceBillingStrategy extends BillingStrategy {
    @Override
    public double calculate(double baseAmount) {
        return baseAmount * 0.2; // patient pays 20%
    }
}
