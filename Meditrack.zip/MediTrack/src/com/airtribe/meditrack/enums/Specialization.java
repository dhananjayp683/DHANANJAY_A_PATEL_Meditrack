package com.airtribe.meditrack.enums;

public enum Specialization {
    CARDIOLOGY, ORTHOPEDIC, NEUROLOGY, GENERAL
}
