package com.airtribe.meditrack.enums;

public enum AppointmentStatus {
    CONFIRMED, CANCELLED, PENDING
}

