package com.airtribe.meditrack.interfaces;

public interface Searchable<T> {
    T searchById(int id);

    default boolean exists(T obj) {
        return obj != null;
    }
}
