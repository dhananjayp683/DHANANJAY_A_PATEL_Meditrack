package com.airtribe.meditrack.interfaces;

public interface Payable {
    double pay();
}
