package com.airtribe.meditrack.test;

public class TestRunner {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
