package com.airtribe.meditrack.entity;

import com.airtribe.meditrack.interfaces.Payable;

public class Bill implements Payable {
    private double amount;

    public Bill(double amount) {
        this.amount = amount;
    }

    @Override
    public double pay() {
        return amount;
    }
}
