package com.airtribe.meditrack.entity;

public class Patient extends Person implements Cloneable {

    private String illness;

    public Patient(int id, String name, int age, String illness) {
        super(id, name, age);
        this.illness = illness;
    }

    public String getIllness() {
        return illness;
    }

    @Override
    public Patient clone() {
        return new Patient(id, name, age, illness); // deep copy
    }

    @Override
    public void display() {
        System.out.println("Patient: " + name + " | " + illness);
    }
}
