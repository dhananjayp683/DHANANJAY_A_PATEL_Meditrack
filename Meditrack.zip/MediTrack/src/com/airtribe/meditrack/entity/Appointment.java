package com.airtribe.meditrack.entity;

import com.airtribe.meditrack.enums.AppointmentStatus;

public class Appointment implements Cloneable {
    private int id;
    private Doctor doctor;
    private Patient patient;
    private AppointmentStatus status;

    public Appointment(int id, Doctor d, Patient p) {
        this.id = id;
        this.doctor = d;
        this.patient = p;
        this.status = AppointmentStatus.PENDING;
    }

    public void cancel() {
        this.status = AppointmentStatus.CANCELLED;
    }

    @Override
    public Appointment clone() {
        return new Appointment(id, doctor, patient.clone());
    }
}
