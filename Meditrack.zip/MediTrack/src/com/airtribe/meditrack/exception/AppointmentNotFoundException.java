package com.airtribe.meditrack.exception;

public class AppointmentNotFoundException {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
