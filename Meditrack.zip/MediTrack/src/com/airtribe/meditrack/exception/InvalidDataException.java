package com.airtribe.meditrack.exception;

public class InvalidDataException {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
