//package com.airtribe.meditrack;

import com.airtribe.meditrack.entity.*;
import com.airtribe.meditrack.enums.Specialization;
import com.airtribe.meditrack.service.*;
import com.airtribe.meditrack.util.IdGenerator;

import java.util.Scanner;

public class Main {

    private static DoctorService doctorService = new DoctorService();
    private static PatientService patientService = new PatientService();
    private static AppointmentService appointmentService = new AppointmentService();

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        int choice;

        do {
            System.out.println("\n--- MediTrack Menu ---");
            System.out.println("1. Add Doctor");
            System.out.println("2. Add Patient");
            System.out.println("3. Create Appointment");
            System.out.println("4. Cancel Appointment");
            System.out.println("5. List Doctors");
            System.out.println("6. List Patients");
            System.out.println("7. Generate Bill");
            System.out.println("0. Exit");

            choice = sc.nextInt();

            switch (choice) {

                case 1 -> {
                    int id = IdGenerator.generate();
                    System.out.print("Doctor name: ");
                    String name = sc.next();
                    System.out.print("Age: ");
                    int age = sc.nextInt();
                    System.out.print("Fee: ");
                    double fee = sc.nextDouble();

                    Doctor d = new Doctor(id, name, age,
                            Specialization.GENERAL, fee);
                    doctorService.addDoctor(id, d);
                }

                case 2 -> {
                    int id = IdGenerator.generate();
                    System.out.print("Patient name: ");
                    String name = sc.next();
                    System.out.print("Age: ");
                    int age = sc.nextInt();
                    System.out.print("Illness: ");
                    String illness = sc.next();

                    Patient p = new Patient(id, name, age, illness);
                    patientService.addPatient(id, p);
                }

                case 3 -> {
                    System.out.print("Doctor ID: ");
                    int dId = sc.nextInt();
                    System.out.print("Patient ID: ");
                    int pId = sc.nextInt();

                    Appointment a = new Appointment(
                            IdGenerator.generate(),
                            doctorService.getDoctor(dId),
                            patientService.getPatient(pId)
                    );

                    appointmentService.createAppointment(a.hashCode(), a);
                }

                case 4 -> {
                    System.out.print("Appointment ID: ");
                    int aId = sc.nextInt();
                    appointmentService.cancelAppointment(aId);
                }

                case 7 -> {
                    System.out.print("Enter base amount: ");
                    double amt = sc.nextDouble();

                    BillingStrategy strategy = new StandardBillingStrategy();
                    System.out.println("Total Bill: " +
                            strategy.calculate(amt));
                }
            }
        } while (choice != 0);

        sc.close();
    }
}
